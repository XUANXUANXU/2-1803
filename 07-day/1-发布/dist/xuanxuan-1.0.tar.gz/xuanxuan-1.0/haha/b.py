#coding=`utf-8
def en2():
	print("得得得的的多")
