#coding=utf-8
def en():
	print('大大大大大大大')
