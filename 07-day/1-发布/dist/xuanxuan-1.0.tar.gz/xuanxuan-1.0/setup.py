
from distutils.core import setup

setup(name="xuanxuan", version="1.0", description="xuanxuan's module", author="xuanxuan", py_modules=['haha.a', 'haha.b'])

